import React from "react";
import {createStackNavigator} from '@react-navigation/stack';

import HomeScreen from '../pages/HomeScreen';
import AboutScreen from '../pages/AboutScreen';
import Livraria from '../pages/Livraria';

const MainStack = createStackNavigator();

export default () => (
  <MainStack.Navigator>
    <MainStack.Screen name="Home" component={HomeScreen} options={{
      title: 'RollMaster',
      headerTitleAlign: 'center',
      headerStyle: {
        backgroundColor: '#A020F0',
        height: 120
      },
      headerTitleStyle:{
        color:'#fff',
        fontSize: 35,
        fontWeight: 'bold'
      }
    }}/>
    <MainStack.Screen name="About" component={AboutScreen} options={({route})=>({
      title: route.params?.name || "Visitante"
      
      
    })}  />
    <MainStack.Screen name="Livraria" component={Livraria} options={({route})=>({  
    })}  />

  </MainStack.Navigator>
);

