import React from 'react';
import {View, Text, StyleSheet, Button, TouchableOpacity, Image, ScrollView, SafeAreaView} from 'react-native';
import {useNavigation, useRoute} from "@react-navigation/native";

function AboutScreen(props) {
  const navigation = useNavigation();
  const route = useRoute();

  const name = props.route.params?.name || 'Visitante';
  const handleBackButton = () => {
    //navigation.goBack();
    //navigation.navigate('Home')
    //navigation.push('Home')
    navigation.popToTop();
  }
  return(
<SafeAreaView style={styles.container}>
  <ScrollView>
    <View style={styles.container}>
    
      <Text style={styles.subtitle}>Bem Vindo {name}</Text>
      <Image
        source={require('../../assets/RollMaster.png')}
        style={styles.img}
      />
      <Text style={styles.text}>O que vamos fazer hoje?</Text>
      <TouchableOpacity title="Voltar" style={styles.opcoes} >
        <Text style={{ textAlign: 'center', color:'#FFF', fontSize: 18, }}>Livraria</Text>
      </TouchableOpacity>
      <TouchableOpacity title="Voltar" style={styles.opcoes} >
        <Text style={{ textAlign: 'center', color:'#FFF', fontSize: 18, }}>Assinaturas</Text>
      </TouchableOpacity>
      <TouchableOpacity title="Voltar" style={styles.opcoes} >
        <Text style={{ textAlign: 'center', color:'#FFF', fontSize: 18, }}>Meu Perfil</Text>
      </TouchableOpacity>
      <TouchableOpacity title="Voltar" style={styles.btn} onPress={handleBackButton}>
        <Text style={{ textAlign: 'center', color:'#FFF', fontSize: 18, }}>Voltar</Text>
      </TouchableOpacity>
    </View>
  </ScrollView>
</SafeAreaView>   

  );
}
const styles = StyleSheet.create({
  container:{
    backgroundColor: '#1C1C1C',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  subtitle:
  {
    fontSize: 40 ,
    color: '#ffffff',
    textAlign: 'center',
    fontStyle: 'italic',
    marginBottom: 15,
  },
  btn:{
    width: 150,
    marginTop: 20,
    padding: 10,
    backgroundColor: '#A020F0',
    borderRadius: 20,
    
  },
  text:{
    color:'#FFF',
    fontSize: 20
  },
  opcoes:{
    width: 350,
    marginTop: 20,
    padding: 10,
    backgroundColor: '#7B68EE',
    borderRadius: 20,
  },
  img:{
    width: 300, 
    height: 300, 
    marginBottom: -20, 
    marginTop: -70 
  },
});



export default AboutScreen;