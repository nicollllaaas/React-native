import React, {useState} from "react";
import {View, Text, StyleSheet, Button, TextInput, ScrollView, SafeAreaView, Image, TouchableOpacity} from 'react-native';

import {useNavigation} from "@react-navigation/native";

function HomeScreen() {
  const navigation = useNavigation();
  const[name, setName] = useState('');
  const[pass, setPass] = useState('');
  const handleSendButton = () => {
    navigation.navigate('About', {
      name: name
  }
    );
  }

  return(
    <SafeAreaView style={styles.container}>
    <ScrollView>
    <View style={styles.container}>
      <Text style ={styles.subtitle}>CRIE SUA PRÓPRIA AVENTURA</Text>
       <Image
        source={require('../../assets/RollMaster.png')}
        style={styles.img}
      />
     
     <Text style={styles.login}>Login</Text>
      <TextInput style={styles.input} value={name} onChangeText={t=>setName(t)} placeholder='Nome' placeholderTextColor="#888" />
      <TextInput style={styles.input} value={pass} onChangeText={p=>setPass(p)} placeholder='Senha' placeholderTextColor="#888" secureTextEntry />
    
      <TouchableOpacity title="Entrar" style={styles.btn} onPress={handleSendButton}>
        <Text style={{ textAlign: 'center', color:'#FFF', fontSize: 18, }}> Entrar </Text>
      </TouchableOpacity>

      <TouchableOpacity title="Entrar" style={styles.visit} onPress={handleSendButton}>
        <Text style={{ textAlign: 'center', color:'#FFF', fontSize: 15, }}> É novo? entre como Visitante </Text>
      </TouchableOpacity>

    </View>  
      
    </ScrollView>
     </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container:{
    backgroundColor: '#1C1C1C',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  input:{
    width: 250,
    padding: 10,
    fontSize: 15,
    backgroundColor: '#DDD',
    borderRadius: 25,
    
    marginTop: 10,
    

  },
  btn:{
    width: 150,
    marginTop: 20,
    padding: 10,
    backgroundColor: '#A020F0',
    borderRadius: 20,
    
  },
 
  subtitle:
  {
    fontSize: 30 ,
    color: '#ffffff',
    textAlign: 'center',
    fontStyle: 'italic',
    marginTop: 10,
    marginBottom: 15,
  },
  img:{
    width: 300, 
    height: 300, 
    marginBottom: -20, 
    marginTop: -70 
  },
  login:{
    color: '#FFF',
    textAlign: 'center',
    fontSize: 25
  },
  visit:{
    width: 250,
    marginTop: 20,
    padding: 10,
    backgroundColor: '#A020F0',
    borderRadius: 20,
  }
  




})
export default HomeScreen;