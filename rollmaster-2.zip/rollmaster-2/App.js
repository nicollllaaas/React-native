import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
 
import MainStack from './src/navigators/MainStack';
//import AboutScreen from './src/pages/AboutScreen';
//import HomeScreen from './src/pages/HomeScreen';
 
function App(){
  return(
    <NavigationContainer>
      <MainStack />
    </NavigationContainer>
  );
}
export default App;