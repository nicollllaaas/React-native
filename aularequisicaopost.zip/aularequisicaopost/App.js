import React, {useState} from 'react';
import {StyleSheet, Text, SafeAreaView, Button, TextInput, View} from 'react-native';

const App = () => {

const [title, setTitle] = useState('');
const [body, setBody] = useState('');

const handleSend = async () => {
  if(title != '' && body != ''){
    const req = await fetch('https://jsonplaceholder.typicode.com/posts', {
      method: 'POST', 
      body: JSON.stringify({

        title: title, 
        body: body,
        userId: 345
      }),//Pega os itens para armazenar na API.

      headers: {
        'Content-Type': 'application/json'
      }
    });
    //Pegar a resposta da requisição.
    const json = await req.json();
    alert("ADICIONADO! ID: " +json.id+" - "+json.title+" - "+json.body);
  }
  else{
    alert("Preencha as informações!");
  }
}

return(
  <SafeAreaView style={styles.container}>
    <Text style={styles.inputLabel}>Título</Text>
    <TextInput value={title} style={styles.input} onChangeText={t=>setTitle(t)} />

    <Text style={styles.inputLabel}>Corpo: </Text>
    <TextInput value={body} style={styles.input} onChangeText={t=>setBody(t)} />

    <Button title='Envia' onPress={handleSend} />

  </SafeAreaView>

);

}

const styles = StyleSheet.create({

container: {
  flex: 1,
  backgroundColor: '#333',
  padding: 20
},
inputLabel:{
  fontSize: 20,
  color: '#fff',
  marginBottom: 10
},
input:{
  backgroundColor: '#555',
  height: 45,
  fontSize: 10,
  color: '#fff',
  paddingLeft: 10,
  paddingRight: 10,
  marginBottom: 30,
  borderRadius: 5 
}
});


export default App;