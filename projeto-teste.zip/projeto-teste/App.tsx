import { Button, SafeAreaView, StyleSheet, Text, View} from "react-native";
import {useState} from "react";

const App = () => {
  
  const [name,setName] = useState('Ninguém');
  const [lastName, setLastName] = useState ('Alguém');
  const [showOptions, setShowOptions] = useState (true);
  const handleButton1 = () => {setName('Nicolas');setLastName ('Kuhn Ferreira') }
  const handleButton2 = () => {setName('Luiz Eduardo'); setLastName ('Pereira Ribas')}
  const handleOptionsButton = () => {setShowOptions(!showOptions);}


return (
  <SafeAreaView>
    <Text style = {styles.title}>Brincando com nomes</Text>
    <Text style = {styles.subtitle}>Meu nome é: {name} {lastName}</Text>
    {showOptions &&
    <View style = {styles.box}>
    <Button title = "Mudar para Nicolas" onPress = {handleButton1}/>
    <Button title = "Mudar para Luiz Eduardo" onPress = {handleButton2}/>
    </View>
    }
    <Button title = {`${showOptions ? 'Ocultar': 'Mostrar'} opções`} onPress = {handleOptionsButton}/>
  </SafeAreaView>
);

}

const styles = StyleSheet.create({
  title:{
    fontSize: 24,
    color: '#0000ff',
    textAlign: 'center',
    marginTop: 20
  },
  subtitle: {
    fontSize: 19,
    color: '#708090',
    textAlign: 'center',
    marginTop: 50,
    marginBottom: 50
  },
  box: {
    borderColor: '#000000',
    borderStyle: 'dotted',
    borderWidth: 2,
    margin: 10,
    padding: 10,
    borderRadius: 20
  }




} );

export default App;