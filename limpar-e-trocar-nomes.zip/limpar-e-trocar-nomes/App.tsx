import { View, Text, Image, ImageBackground, Button } from 'react-native';
import React, {useState} from 'react';
const App = () => {
const [name, setName] = useState('Nicolas');
const [age, setAge] = useState(20);
const turnIntoUpperCase = (str: string) => {
  return str.toUpperCase();
}
const handleClear = () =>{
  setName('');
  setAge(0);
}
  return (
    <View>
      <Text>Olá {turnIntoUpperCase(name)} vc tem {age} anos</Text>
      {name != '' && 
      <Button title = "Limpar tudo" onPress = {handleClear}/>
      }
      {name == '' &&
      <View>

      
       <Button title = "Mudar para Eduardo" onPress = {() => {setName('Eduardo'); setAge(8000)}}/>
       <Button title = "Mudar para Luiz" onPress = {() => {setName('Luiz'); setAge(2200)} }/>
       <Button title = "Mudar para Clodoege" onPress = {() => {setName('Clodoege'); setAge(18)} }/>
       <Button title = "Mudar para Reinald" onPress = {() => {setName('Reinald'); setAge(15)} }/>
       <Button title = "Mudar para Rodrigo" onPress = {() => {setName('Rodrigo'); setAge(41)} }/>
       

       </View>
       }
      
    </View>

  );
};

export default App;
